
package Tienda;

import Tienda.Services.ServicioTienda;

/**
 *
 * @author Xhemanuelv
 */
public class Tienda {

    /**
     * @param args the command line arguments
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        ServicioTienda servTienda=new ServicioTienda();
        servTienda.menu();
    }

}
