package Tienda.Persistence;

import Tienda.Entities.Producto;
import java.util.ArrayList;

/**
 *
 * @author Xhemanuelv
 */
public class ProductoDao extends DAO {

    /**
     * Agrega un producto a la base de datos
     *
     * @param producto
     * @throws Exception
     */
    public void cargarProducto(Producto producto) throws Exception {
        try {
            if (producto == null) {
                throw new Exception("Debe ingresar un producto");
            }

            String sql = "INSERT INTO producto (codigo,nombre,precio,codigo_fabricante) VALUES('"
                    + producto.getCodigo()
                    + "','" + producto.getNombre()
                    + "','" + producto.getPrecio()
                    + "','" + producto.getCodigo_fabricante() + "');";
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Modifica un producto de la base de datos
     *
     * @param producto
     * @throws Exception
     */
    public void modificarProductoPorCodigo(Producto producto) throws Exception {
        try {
            if (producto == null) {
                throw new Exception("Debe ingresar un producto");
            }

            String sql = "UPDATE producto SET " + "nombre ='" 
                    + producto.getNombre() 
                    + "', precio = '" 
                    + producto.getPrecio() 
                    + "', codigo_fabricante = '" 
                    + producto.getCodigo_fabricante() 
                    + "' WHERE codigo = '" 
                    + producto.getCodigo() + "';";
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Elimina un producto de la base de datos por nombre
     *
     * @param nombre
     * @throws java.lang.Exception
     *
     */
    public void eliminarProductoPorNombre(String nombre) throws Exception {
        try {
            if (nombre == null) {
                throw new Exception("Debe indicar el nombre del fabricante a eliminar");
            }

            String sql = "DELETE FROM  producto WHERE nombre = '" + nombre + "';";

            insertarModificarEliminar(sql);

        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Elimina un producto de la base de datos por codigo o id
     *
     * @param iD
     * @throws java.lang.Exception
     */
    public void eliminarProductoPorID(int iD) throws Exception {
        try {
            String sql = "DELETE FROM producto WHERE codigo = '" + iD + "';";
            insertarModificarEliminar(sql);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Buscar producto individual Se debe ingresar el query
     *
     * @param sql
     * @return
     * @throws Exception
     */
    public Producto buscarProducto(String sql) throws Exception {
        Producto prod = null;
        try {
            consultarBase(sql);

            while (resultado.next()) {
                prod = new Producto();
                prod.setCodigo(resultado.getInt(1));
                prod.setNombre(resultado.getString(2));
                prod.setPrecio(resultado.getDouble(3));
                prod.setCodigo_fabricante(resultado.getInt(4));
            }
            desconectarBase();
            return prod;
        } catch (Exception e) {
            desconectarBase();
            throw e;
        }
    }

    /**
     * Buscar lista de productos,retorna todos los objetos de tabla
     *
     * @return
     * @throws java.lang.Exception
     */
    public ArrayList<Producto> listarProductos() throws Exception {
        ArrayList<Producto> prodList = new ArrayList();
        try {
            String sql = "SELECT * FROM producto;";
            consultarBase(sql);
            while (resultado.next()) {
                Producto prod = new Producto();
                prod.setCodigo(resultado.getInt(1));
                prod.setNombre(resultado.getString(2));
                prod.setPrecio(resultado.getDouble(3));
                prod.setCodigo_fabricante(resultado.getInt(4));
                prodList.add(prod);

            }
            desconectarBase();
            return prodList;
        } catch (Exception e) {
            desconectarBase();
            throw e;
        }
    }

    /**
     * Busca lista de productos que cumplan ciertas condiciones requiere como
     * ingreso un sql con todos los datos y la condicion a limitar
     *
     * @param sql
     * @return
     * @throws Exception
     */
    public ArrayList<Producto> listarProductosCondicion(String sql) throws Exception {
        ArrayList<Producto> prodList = new ArrayList();
        try {
            consultarBase(sql);
            while (resultado.next()) {
                Producto prod = new Producto();
                prod.setCodigo(resultado.getInt(1));
                prod.setNombre(resultado.getString(2));
                prod.setPrecio(resultado.getDouble(3));
                prod.setCodigo_fabricante(resultado.getInt(4));

                prodList.add(prod);

            }
            desconectarBase();
            return prodList;
        } catch (Exception e) {
            desconectarBase();
            throw e;
        }

    }
}
