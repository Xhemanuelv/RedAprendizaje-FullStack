package Tienda.Services;

import Tienda.Entities.Fabricante;
import Tienda.Persistence.FabricanteDao;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Xhemanuelv
 */
public class FabricanteService {

    private FabricanteDao fabDAO = new FabricanteDao();
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    private Fabricante agregaFabricante() throws Exception {
        System.out.println("Ingresar codigo Fabricante");
        int cod = leer.nextInt();
        System.out.println("Ingresar nombre Fabricante");
        String nombre = leer.next();
        return new Fabricante(cod, nombre);

    }

    protected void ingresarFabricanteEnBD() throws Exception {

        try {
            Fabricante f1 = agregaFabricante();
            fabDAO.cargarFabricante(f1);
        } catch (Exception e) {
            throw e;
        }
    }

    protected void listaFabricantes() throws Exception {
        ArrayList<Fabricante> listaFabricantes = fabDAO.listarFabricantes();

        for (Fabricante fabricante : listaFabricantes) {
            System.out.println(fabricante);
        }
    }

}
