package Tienda.Services;

import Tienda.Entities.Producto;
import Tienda.Persistence.ProductoDao;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Xhemanuelv
 */
public class ProductoService {

    private ProductoDao proDAO = new ProductoDao();
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    /**
     * Crea un producto y lo agrega a la base de datos
     *
     * @return
     * @throws Exception
     */
    protected Producto crearProducto() throws Exception {
        Producto producto = new Producto();
        System.out.println("Ingrese el codigo de producto");
        producto.setCodigo(leer.nextInt());

        System.out.println("Ingrese el nombre de producto");
        producto.setNombre(leer.next());

        System.out.println("Ingrese el precio de producto");
        producto.setPrecio(leer.nextDouble());

        System.out.println("Ingrese el codigo de fabricante del producto");
        producto.setCodigo_fabricante(leer.nextInt());
        proDAO.cargarProducto(producto);
        return producto;
    }

    /**
     * Modificar un producto.Recibe un producto buscado por ID/codigo
     *
     * @param producto
     * @throws Exception
     */
    protected void modificarProducto(Producto producto) throws Exception {

        try {
            System.out.println("Se modificara el producto " + producto.getNombre());
            System.out.println("Ingrese el nombre de producto");
            producto.setNombre(leer.next());
            System.out.println("Ingrese el precio de producto");
            producto.setPrecio(leer.nextDouble());
            System.out.println("Ingrese el codigo de fabricante del producto");
            producto.setCodigo_fabricante(leer.nextInt());
            proDAO.modificarProductoPorCodigo(producto);
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Muestra una lista de todos los nombres de los productos
     *
     * @throws Exception
     */
    protected void listarTodosLosProductosNombre() throws Exception {

        ArrayList<Producto> listaProductos = new ArrayList();

        listaProductos = proDAO.listarProductos();
        System.out.println("Los productos encontrados fueron :");
        for (Producto producto : listaProductos) {

            System.out.println(producto.getNombre());
        }
        System.out.println("");

    }

    /**
     * Muestra una lista de todos los nombres y precios de los productos
     *
     * @throws Exception
     */
    protected void listarTodosLosProductosNombrePrecio() throws Exception {

        ArrayList<Producto> listaProductos = new ArrayList();

        listaProductos = proDAO.listarProductos();
        System.out.println("Los productos encontrados fueron :");
        for (Producto producto : listaProductos) {

            System.out.println(producto);
//            System.out.println(producto.getNombre() + ", $ " + producto.getPrecio());
        }
        System.out.println("");
    }

    /**
     * Muestra una lista de productos limitado por condicion.Condicion recibida
     * mediante string sql
     *
     * @param sql
     * @return
     * @throws Exception
     */
    protected ArrayList<Producto> productosCondicion(String sql) throws Exception {
        ArrayList<Producto> listaProductos = proDAO.listarProductosCondicion(sql);
        for (Producto prodAux : listaProductos) {
            System.out.println(prodAux);
        }
        System.out.println("");
        return listaProductos;
    }

}
