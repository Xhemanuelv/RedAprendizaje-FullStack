package Libreria.Servicios;

import Libreria.Entidades.Editorial;
import Libreria.Persistencia.PersistenceController;

/**
 *
 * @author Xhemanuelv
 */
public class EditorialService {

    PersistenceController persistenceController = new PersistenceController();

    public void crearEditorial(Editorial editorial) {
        persistenceController.createEditorial(editorial);
    }

    public void consultaEditorial() {

    }

    public void modificarEditorial(Editorial editorial) {
        persistenceController.editEditorial(editorial);
    }

    public void eliminarEditorial(Integer id) {
        persistenceController.deleteEditorial(id);
    }
}
